// Variation B — Tape Timeline
// Bigger leap: the chord progression IS the tape. One continuous horizontal strip
// that "plays through" sections. Home screen emphasizes the cassette stack.

function V2_Home({ theme, onSelectStation, onResume }) {
  const t = theme;
  return (
    <div style={{ padding: '20px 16px 20px', display: 'flex', flexDirection: 'column', gap: 18, minHeight: '100%', boxSizing: 'border-box' }}>
      {/* Logo */}
      <div style={{ textAlign: 'center', paddingTop: 4 }}>
        <div style={{
          fontFamily: '"Playfair Display", Georgia, serif',
          fontStyle: 'italic', fontWeight: 700, fontSize: 30,
          background: t.logoGradient, WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent', backgroundClip: 'text',
          letterSpacing: 0.5,
        }}>Guitar Chord Radio</div>
        <div style={{ fontFamily: t.uiFont, fontSize: 12, color: t.muted, letterSpacing: 3, marginTop: 2 }}>
          ギターコードラジオ
        </div>
      </div>

      {/* Big hero cassette */}
      <V2_BigCassette theme={t} song={{ title: 'Hello, Again', artist: 'My Little Lover', side: 'A' }} onClick={onResume}/>

      {/* Decade stack — flat shelf */}
      <div>
        <div style={{ fontFamily: t.monoFont, fontSize: 11, color: t.muted, letterSpacing: 2, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
          <span>STATIONS</span>
          <span style={{ flex: 1, height: 1, background: t.panelBorderColor }} />
          <span style={{ opacity: 0.7 }}>3</span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {DECADES.map((d) => (
            <V2_DecadeShelf key={d.id} decade={d} theme={t} onClick={() => onSelectStation(d.id)} />
          ))}
        </div>
      </div>

      {/* Small stats / equalizer-like strip */}
      <div style={{
        background: t.panelBg, borderRadius: 10, padding: '10px 14px',
        border: t.panelBorder, display: 'flex', gap: 16, alignItems: 'center',
      }}>
        <div style={{ display: 'flex', gap: 2, alignItems: 'flex-end', height: 22 }}>
          {[40, 70, 55, 85, 60, 45, 75, 50, 65].map((h, i) => (
            <div key={i} style={{
              width: 3, height: `${h}%`, background: i < 5 ? t.accent : t.muted,
              opacity: i < 5 ? 1 : 0.4, borderRadius: 1,
            }}/>
          ))}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted, letterSpacing: 1.5 }}>LISTENING TIME</div>
          <div style={{ fontFamily: t.uiFont, fontSize: 14, color: t.text, fontWeight: 600 }}>12h 34m this week</div>
        </div>
        <div style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted }}>▸</div>
      </div>

      <div style={{ flex: 1 }} />
      <V1_KnobRow theme={t} />
    </div>
  );
}

function V2_BigCassette({ theme, song, onClick }) {
  const t = theme;
  return (
    <div onClick={onClick} style={{
      background: t.cassetteBg, borderRadius: 10, padding: 14,
      border: `1px solid ${t.panelBorderColor}`,
      boxShadow: 'inset 0 2px 6px rgba(0,0,0,0.4), 0 4px 16px rgba(0,0,0,0.3)',
      cursor: 'pointer', position: 'relative',
    }}>
      {/* screw dots */}
      {[[8,8],[null,8,8],[8,null,null,8],[null,8,null,8]].length && [
        { top: 8, left: 8 }, { top: 8, right: 8 }, { bottom: 8, left: 8 }, { bottom: 8, right: 8 },
      ].map((p, i) => (
        <div key={i} style={{
          position: 'absolute', ...p, width: 6, height: 6, borderRadius: '50%',
          background: 'radial-gradient(circle at 30% 30%, #666, #222)', opacity: 0.7,
        }}/>
      ))}

      {/* Label area */}
      <div style={{
        background: `linear-gradient(180deg, ${t.accent}22, ${t.accent}08)`,
        border: `0.5px solid ${t.accent}44`,
        borderRadius: 4, padding: '10px 12px', marginBottom: 10,
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
          <span style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted, letterSpacing: 2 }}>RESUME ・ SIDE {song.side}</span>
          <span style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted }}>03:42 / 05:18</span>
        </div>
        <div style={{
          fontFamily: t.uiFont, fontWeight: 700, fontSize: 18, color: t.text,
          marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        }}>{song.title}</div>
        <div style={{ fontFamily: t.monoFont, fontSize: 11, color: t.muted }}>{song.artist}</div>
      </div>

      {/* Tape window */}
      <div style={{
        background: 'rgba(0,0,0,0.65)', borderRadius: 4,
        padding: '14px 20px', border: `0.5px solid ${t.panelBorderColor}`,
        display: 'flex', alignItems: 'center', gap: 14, position: 'relative',
      }}>
        <V2_TapeReel theme={t} fill={0.7} spinning />
        <div style={{ flex: 1, height: 3, background: t.accent, borderRadius: 2, opacity: 0.8, boxShadow: `0 0 6px ${t.accent}88` }}/>
        <V2_TapeReel theme={t} fill={0.3} spinning />
      </div>

      {/* Play bar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 10 }}>
        <div style={{
          width: 36, height: 36, borderRadius: 18, background: t.accent,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: `0 0 10px ${t.accent}66`,
        }}>
          <svg width="12" height="12" viewBox="0 0 12 12"><path d="M2 1v10l8-5z" fill={t.bg}/></svg>
        </div>
        <div style={{ flex: 1, height: 4, background: t.panelBorderColor, borderRadius: 2, position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '65%', background: t.accent }}/>
        </div>
        <span style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted }}>TAP TO PLAY ›</span>
      </div>
    </div>
  );
}

function V2_TapeReel({ theme, fill = 0.5, spinning, size = 38 }) {
  const t = theme;
  const rInner = size * 0.15;
  const rFill = rInner + (size * 0.32) * fill;
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: '#1a1a1a', border: `1px solid ${t.panelBorderColor}`,
      position: 'relative',
      animation: spinning ? 'spin 4s linear infinite' : 'none',
    }}>
      {/* tape wound on reel */}
      <div style={{
        position: 'absolute', top: '50%', left: '50%',
        width: rFill * 2, height: rFill * 2, borderRadius: '50%',
        transform: 'translate(-50%, -50%)',
        background: `radial-gradient(circle, transparent ${rInner}px, ${t.accent}66 ${rInner}px)`,
      }}/>
      {/* 3 spokes */}
      {[0, 120, 240].map(a => (
        <div key={a} style={{
          position: 'absolute', top: '50%', left: '50%', width: 2, height: size * 0.35,
          background: '#333', transform: `translate(-50%, -50%) rotate(${a}deg)`, transformOrigin: 'center',
        }}/>
      ))}
      {/* hub */}
      <div style={{
        position: 'absolute', top: '50%', left: '50%',
        width: rInner * 2, height: rInner * 2, borderRadius: '50%',
        background: '#0a0a0a', transform: 'translate(-50%, -50%)',
        border: `1px solid ${t.panelBorderColor}`,
      }}/>
    </div>
  );
}

function V2_DecadeShelf({ decade, theme, onClick }) {
  const t = theme;
  // Decade color-coded tape spine
  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'stretch', gap: 0, cursor: 'pointer',
      background: t.cardBg, borderRadius: 10, overflow: 'hidden',
      border: t.panelBorder,
    }}>
      {/* Cassette spine */}
      <div style={{
        width: 58, background: t.cassetteBg,
        borderRight: `1px solid ${t.panelBorderColor}`,
        position: 'relative',
        display: 'flex', alignItems: 'center', justifyContent: 'space-around', padding: '0 6px',
      }}>
        <div style={{
          position: 'absolute', top: 6, left: 4, right: 4, height: 3,
          background: decade.accent, borderRadius: 1, opacity: 0.9,
        }}/>
        <V2_TapeReel theme={t} fill={0.5} size={18} />
        <V2_TapeReel theme={t} fill={0.5} size={18} />
        <div style={{
          position: 'absolute', bottom: 6, left: 4, right: 4, height: 3,
          background: decade.accent, borderRadius: 1, opacity: 0.4,
        }}/>
      </div>
      {/* Info */}
      <div style={{ flex: 1, padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: t.uiFont, fontSize: 18, fontWeight: 700, color: t.text, lineHeight: 1 }}>{decade.label}</div>
          <div style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted, letterSpacing: 2, marginTop: 3 }}>
            {decade.en} ・ {SONGS_BY_DECADE[decade.id].length} TRACKS
          </div>
        </div>
        <div style={{
          fontFamily: t.monoFont, fontSize: 9, color: decade.accent, letterSpacing: 1,
          border: `1px solid ${decade.accent}66`, borderRadius: 2, padding: '2px 5px',
        }}>TUNE IN</div>
      </div>
    </div>
  );
}

// ── Player V2 — Tape Timeline ──────────────────────────────────

function V2_Player({ song, theme, onBack }) {
  const t = theme;
  const [liked, setLiked] = React.useState(false);

  // Flatten for timeline view
  const flatProgression = [];
  song.sections.forEach(sec => {
    sec.chords.forEach((c, i) => flatProgression.push({ chord: c, section: sec.name, first: i === 0 }));
  });

  return (
    <div style={{ padding: '14px 0 20px', display: 'flex', flexDirection: 'column', gap: 12, minHeight: '100%', boxSizing: 'border-box' }}>
      {/* Top bar */}
      <div style={{ padding: '0 14px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <button onClick={onBack} style={{
          background: t.cardBg, border: `1px solid ${t.panelBorderColor}`, borderRadius: 8,
          width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}>
          <svg width="12" height="12" viewBox="0 0 12 12"><path d="M8 2L3 6l5 4" stroke={t.text} strokeWidth="1.8" fill="none" strokeLinecap="round"/></svg>
        </button>
        <div style={{ flex: 1, textAlign: 'center' }}>
          <div style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted, letterSpacing: 2 }}>NOW PLAYING</div>
          <div style={{ fontFamily: t.uiFont, fontSize: 14, color: t.text, fontWeight: 700 }}>{song.title}</div>
        </div>
        <button onClick={() => setLiked(!liked)} style={{
          background: t.cardBg, border: `1px solid ${liked ? t.accent : t.panelBorderColor}`, borderRadius: 8,
          width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}>
          <svg width="14" height="13" viewBox="0 0 14 13"><path d="M7 12s-5-3-5-7a3 3 0 015-2.2A3 3 0 0112 5c0 4-5 7-5 7z" fill={liked ? t.accent : 'none'} stroke={liked ? t.accent : t.muted} strokeWidth="1.2"/></svg>
        </button>
      </div>

      {/* Compact YouTube frame */}
      <div style={{ margin: '0 14px', display: 'flex', gap: 10 }}>
        <div style={{
          width: 120, aspectRatio: '16/9', background: t.cassetteBg,
          borderRadius: 6, padding: 4, border: `1px solid ${t.panelBorderColor}`,
        }}>
          <div style={{
            position: 'relative', width: '100%', height: '100%',
            background: '#000', borderRadius: 3, overflow: 'hidden',
          }}>
            <Placeholder theme={t} label="video" />
            <div style={{
              position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
              width: 24, height: 24, borderRadius: '50%', background: 'rgba(0,0,0,0.7)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <svg width="8" height="8" viewBox="0 0 8 8"><path d="M1 0v8l7-4z" fill="#fff"/></svg>
            </div>
          </div>
        </div>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <div style={{ fontFamily: t.uiFont, fontSize: 15, color: t.text, fontWeight: 700, lineHeight: 1.2 }}>{song.title}</div>
          <div style={{ fontFamily: t.monoFont, fontSize: 11, color: t.muted, marginTop: 4 }}>{song.artist} ・ {song.year}</div>
          <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
            <span style={{ fontFamily: t.monoFont, fontSize: 9, color: t.muted, border: `1px solid ${t.panelBorderColor}`, borderRadius: 10, padding: '1px 6px' }}>KEY: C</span>
            <span style={{ fontFamily: t.monoFont, fontSize: 9, color: t.muted, border: `1px solid ${t.panelBorderColor}`, borderRadius: 10, padding: '1px 6px' }}>{song.sections.reduce((s, sec) => s + sec.chords.length, 0)} CHORDS</span>
          </div>
        </div>
      </div>

      {/* Tape timeline — horizontal scrollable strip */}
      <div style={{ margin: '0 0', padding: '12px 0', background: t.panelBg, borderTop: `1px solid ${t.panelBorderColor}`, borderBottom: `1px solid ${t.panelBorderColor}` }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '0 16px 8px', fontFamily: t.monoFont, fontSize: 10, color: t.muted, letterSpacing: 2 }}>
          <span>◀◀  TAPE ▸ A-SIDE</span>
          <span>▶▶</span>
        </div>
        <div style={{
          overflowX: 'auto', overflowY: 'hidden', scrollbarWidth: 'thin',
          padding: '0 16px', WebkitOverflowScrolling: 'touch',
        }}>
          <div style={{ display: 'flex', gap: 0, minWidth: 'max-content', position: 'relative', paddingTop: 6 }}>
            {flatProgression.map((item, i) => {
              const color = chordColor(item.chord);
              return (
                <div key={i} style={{ display: 'flex', alignItems: 'flex-start' }}>
                  {item.first && i > 0 && (
                    <div style={{ display: 'flex', alignItems: 'center', padding: '0 8px' }}>
                      <div style={{ width: 1, height: 60, background: t.panelBorderColor }}/>
                    </div>
                  )}
                  {item.first && (
                    <div style={{ padding: '0 8px', position: 'relative' }}>
                      <div style={{
                        fontFamily: t.monoFont, fontSize: 9, color: t.muted, letterSpacing: 1,
                        writingMode: 'vertical-rl', transform: 'rotate(180deg)',
                        borderLeft: `1px solid ${t.accent}`,
                        paddingLeft: 2, height: 60,
                      }}>{item.section}</div>
                    </div>
                  )}
                  <div style={{
                    width: 54, padding: '0 3px',
                    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
                  }}>
                    <div style={{
                      fontFamily: t.uiFont, fontSize: 14, fontWeight: 700, color,
                      textShadow: `0 0 8px ${color}33`,
                    }}>{item.chord}</div>
                    <ChordDiagram name={item.chord} size={40} stroke={t.text} />
                    {/* tape base line */}
                    <div style={{ width: '100%', height: 2, background: color, opacity: 0.5, borderRadius: 1 }}/>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Section legend */}
      <div style={{ padding: '0 14px', display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {song.sections.map((sec, i) => (
          <div key={i} style={{
            flex: '1 0 auto', background: t.cardBg, borderRadius: 8, padding: '8px 10px',
            border: t.panelBorder,
          }}>
            <div style={{ fontFamily: t.monoFont, fontSize: 9, color: t.muted, letterSpacing: 1.5 }}>{sec.name.toUpperCase()}</div>
            <div style={{ display: 'flex', gap: 3, marginTop: 4 }}>
              {sec.chords.map((c, j) => (
                <div key={j} style={{
                  width: 16, height: 16, borderRadius: 3, background: chordColor(c),
                  fontFamily: t.uiFont, fontSize: 8, color: '#fff', fontWeight: 700,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>{c.replace(/m|maj7|7/g, '')}</div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Transport bottom bar */}
      <div style={{ padding: '0 14px' }}>
        <div style={{
          background: t.cardBg, borderRadius: 10, border: t.panelBorder,
          padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 14,
        }}>
          <span style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted }}>1×</span>
          <div style={{ flex: 1, height: 4, background: t.panelBorderColor, borderRadius: 2, position: 'relative' }}>
            <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '38%', background: t.accent, borderRadius: 2 }}/>
            <div style={{ position: 'absolute', left: '38%', top: -4, width: 12, height: 12, borderRadius: '50%', background: t.accent, transform: 'translateX(-50%)', boxShadow: `0 0 0 2px ${t.bg}` }}/>
          </div>
          <span style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted }}>2:03</span>
        </div>
      </div>

      <div style={{ flex: 1 }} />
      <V1_KnobRow theme={t} />
    </div>
  );
}

Object.assign(window, { V2_Home, V2_Player });
