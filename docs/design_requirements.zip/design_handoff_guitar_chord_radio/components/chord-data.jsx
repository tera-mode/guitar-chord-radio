// Chord data + helpers

// Root-note colors — oklch rainbow, 12 chromatic notes, equal chroma/lightness
// C=red, C#=red-orange, D=orange, D#=amber, E=yellow, F=chartreuse,
// F#=green, G=teal, G#=cyan, A=blue, A#=indigo, B=purple
const ROOT_ORDER = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const ROOT_COLORS = {};
ROOT_ORDER.forEach((n, i) => {
  const hue = (i / 12) * 360;
  ROOT_COLORS[n] = `oklch(0.62 0.17 ${hue})`;
});
// enharmonic aliases
['Db:C#','Eb:D#','Gb:F#','Ab:G#','Bb:A#'].forEach(p => {
  const [a,b] = p.split(':'); ROOT_COLORS[a] = ROOT_COLORS[b];
});

function chordRoot(name) {
  if (!name) return 'C';
  const m = name.match(/^[A-G][#b]?/);
  return m ? m[0] : 'C';
}
function chordColor(name) {
  return ROOT_COLORS[chordRoot(name)] || '#666';
}
function chordQuality(name) {
  if (!name) return '';
  return name.slice(chordRoot(name).length);
}

// Fret patterns for common chords — [fret, fret, fret, fret, fret, fret]
// string order: E A D G B e (low to high). 0=open, -1=mute, number=fret
const CHORD_SHAPES = {
  'C':    [-1, 3, 2, 0, 1, 0],
  'D':    [-1, -1, 0, 2, 3, 2],
  'Dm':   [-1, -1, 0, 2, 3, 1],
  'E':    [0, 2, 2, 1, 0, 0],
  'Em':   [0, 2, 2, 0, 0, 0],
  'F':    [1, 3, 3, 2, 1, 1],
  'G':    [3, 2, 0, 0, 0, 3],
  'A':    [-1, 0, 2, 2, 2, 0],
  'Am':   [-1, 0, 2, 2, 1, 0],
  'B7':   [-1, 2, 1, 2, 0, 2],
  'Bm':   [-1, 2, 4, 4, 3, 2],
  'C7':   [-1, 3, 2, 3, 1, 0],
  'D7':   [-1, -1, 0, 2, 1, 2],
  'G7':   [3, 2, 0, 0, 0, 1],
  'Cmaj7':[-1, 3, 2, 0, 0, 0],
  'Fmaj7':[-1, -1, 3, 2, 1, 0],
  'Am7':  [-1, 0, 2, 0, 1, 0],
  'Dm7':  [-1, -1, 0, 2, 1, 1],
  'Em7':  [0, 2, 2, 0, 3, 0],
};

function getShape(name) {
  return CHORD_SHAPES[name] || CHORD_SHAPES[chordRoot(name) + (name.includes('m') && !name.includes('maj') ? 'm' : '')] || CHORD_SHAPES['C'];
}

// Songs — mocked data
const SONGS_BY_DECADE = {
  '80s': [
    {
      id: 's80-1', title: '君は天然色', artist: '大滝詠一', year: 1981,
      sections: [
        { name: 'イントロ', chords: ['F', 'G', 'Em', 'Am'] },
        { name: 'Aメロ', chords: ['C', 'G', 'Am', 'F', 'C', 'G', 'F', 'G'] },
        { name: 'Bメロ', chords: ['Dm', 'G', 'C', 'Am', 'Dm', 'G'] },
        { name: 'サビ', chords: ['F', 'G', 'C', 'Am', 'F', 'G', 'C'] },
      ],
    },
    {
      id: 's80-2', title: '少年時代', artist: '井上陽水', year: 1990,
      sections: [
        { name: 'イントロ', chords: ['Am', 'F', 'C', 'G'] },
        { name: 'Aメロ', chords: ['Am', 'Em', 'F', 'C', 'Dm', 'G', 'C'] },
        { name: 'サビ', chords: ['F', 'G', 'Em', 'Am', 'F', 'G', 'C'] },
      ],
    },
    {
      id: 's80-3', title: 'ルビーの指環', artist: '寺尾聰', year: 1981,
      sections: [
        { name: 'イントロ', chords: ['Dm', 'G', 'C', 'F'] },
        { name: 'Aメロ', chords: ['Dm', 'G', 'Em', 'Am', 'Dm', 'G', 'C'] },
        { name: 'サビ', chords: ['F', 'Em', 'Dm', 'G', 'C', 'Am', 'Dm', 'G'] },
      ],
    },
  ],
  '90s': [
    {
      id: 's90-1', title: '君がいるだけで', artist: '米米CLUB', year: 1992,
      sections: [
        { name: 'イントロ', chords: ['C', 'G', 'Am', 'F'] },
        { name: 'Aメロ', chords: ['C', 'G', 'Am', 'F', 'Dm', 'Em', 'G'] },
        { name: 'サビ', chords: ['F', 'G', 'C', 'Am', 'Dm', 'G', 'C'] },
      ],
    },
    {
      id: 's90-2', title: 'Hello, Again 〜昔からある場所〜', artist: 'My Little Lover', year: 1995,
      sections: [
        { name: 'イントロ', chords: ['Am7', 'Dm7', 'G7', 'Cmaj7'] },
        { name: 'Aメロ', chords: ['Am', 'Em', 'F', 'C', 'Dm', 'G'] },
        { name: 'サビ', chords: ['F', 'G', 'Em', 'Am', 'Dm', 'G', 'C'] },
      ],
    },
    {
      id: 's90-3', title: 'TOMORROW', artist: '岡本真夜', year: 1995,
      sections: [
        { name: 'イントロ', chords: ['C', 'Em', 'F', 'G'] },
        { name: 'Aメロ', chords: ['C', 'G', 'Am', 'Em', 'F', 'C', 'Dm', 'G'] },
        { name: 'サビ', chords: ['F', 'G', 'Em', 'Am', 'Dm', 'G', 'C'] },
      ],
    },
  ],
  '2000s': [
    {
      id: 's00-1', title: '小さな恋のうた', artist: 'MONGOL800', year: 2001,
      sections: [
        { name: 'イントロ', chords: ['G', 'D', 'Em', 'C'] },
        { name: 'Aメロ', chords: ['G', 'D', 'Em', 'C', 'G', 'D', 'C'] },
        { name: 'サビ', chords: ['C', 'D', 'G', 'Em', 'C', 'D', 'G'] },
      ],
    },
    {
      id: 's00-2', title: 'ハナミズキ', artist: '一青窈', year: 2004,
      sections: [
        { name: 'イントロ', chords: ['C', 'G', 'Am', 'F'] },
        { name: 'Aメロ', chords: ['C', 'G', 'F', 'C', 'Dm', 'G'] },
        { name: 'サビ', chords: ['F', 'G', 'Em', 'Am', 'F', 'G', 'C'] },
      ],
    },
    {
      id: 's00-3', title: '366日', artist: 'HY', year: 2008,
      sections: [
        { name: 'イントロ', chords: ['Em', 'C', 'G', 'D'] },
        { name: 'Aメロ', chords: ['Em', 'D', 'C', 'G', 'Am', 'D'] },
        { name: 'サビ', chords: ['C', 'D', 'G', 'Em', 'Am', 'D', 'G'] },
      ],
    },
  ],
};

const DECADES = [
  { id: '80s', label: '80年代', en: "80's HITS", accent: 'oklch(0.68 0.17 30)' },   // warm amber
  { id: '90s', label: '90年代', en: "90's HITS", accent: 'oklch(0.72 0.15 80)' },    // yellow
  { id: '2000s', label: '2000年代', en: "2000's HITS", accent: 'oklch(0.70 0.13 180)' }, // teal
];

Object.assign(window, {
  ROOT_COLORS, ROOT_ORDER, chordRoot, chordColor, chordQuality,
  CHORD_SHAPES, getShape, SONGS_BY_DECADE, DECADES,
});
