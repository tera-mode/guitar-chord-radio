// Variation A — Walkman Classic
// Safe refinement of current design, committed to cassette/walkman aesthetic
// - Cassette reels visible and animated when playing
// - Progression as horizontal scrolling "tape" with color-coded root notes
// - YouTube embed framed like a cassette window

function V1_Home({ theme, onSelectStation, onResume }) {
  const t = theme;
  return (
    <div style={{ padding: '20px 18px 24px', display: 'flex', flexDirection: 'column', gap: 20, minHeight: '100%', boxSizing: 'border-box' }}>
      {/* Logo header */}
      <div style={{ textAlign: 'center', paddingTop: 8 }}>
        <div style={{
          fontFamily: '"Playfair Display", Georgia, serif',
          fontStyle: 'italic', fontWeight: 700, fontSize: 32,
          background: t.logoGradient, WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent', backgroundClip: 'text',
          letterSpacing: 0.5, lineHeight: 1.1,
        }}>Guitar Chord Radio</div>
        <div style={{ fontFamily: t.uiFont, fontSize: 13, color: t.muted, letterSpacing: 3, marginTop: 4 }}>
          ギターコードラジオ
        </div>
      </div>

      {/* Tuning dial display */}
      <div style={{
        background: t.panelBg, borderRadius: 14, padding: '14px 18px',
        border: t.panelBorder, boxShadow: t.panelShadow,
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
          <span style={{ fontFamily: t.monoFont, fontSize: 11, color: t.muted, letterSpacing: 1 }}>FM TUNING</span>
          <span style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted }}>MHz</span>
        </div>
        <V1_Dial theme={t} />
      </div>

      {/* Terminal message */}
      <div style={{
        background: t.terminalBg, borderRadius: 10, padding: '12px 14px',
        border: `1px solid ${t.terminalBorder}`,
        fontFamily: t.monoFont, fontSize: 12, color: t.terminalText, lineHeight: 1.6,
      }}>
        <span style={{ opacity: 0.6 }}>&gt; </span>
        ギターを構えた30秒後には、<br/>
        <span style={{ marginLeft: 12 }}>もう弾いている。</span>
        <span style={{ display: 'inline-block', width: 7, height: 13, background: t.terminalText, marginLeft: 4, verticalAlign: -2, animation: 'blink 1s step-end infinite' }} />
      </div>

      {/* Resume */}
      <div onClick={onResume} style={{
        background: t.cardBg, borderRadius: 14, padding: '12px 14px',
        border: t.panelBorder, display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer',
      }}>
        <div style={{
          width: 42, height: 42, borderRadius: 21, background: t.accent,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: `0 0 0 3px ${t.bg}, 0 0 0 4px ${t.accent}33`,
        }}>
          <svg width="14" height="14" viewBox="0 0 14 14"><path d="M2 1.5v11l10-5.5z" fill={t.bg}/></svg>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted, letterSpacing: 1.5 }}>RESUME</div>
          <div style={{ fontFamily: t.uiFont, fontSize: 15, color: t.text, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            Hello, Again 〜昔からある場所〜
          </div>
          <div style={{ fontFamily: t.monoFont, fontSize: 11, color: t.muted }}>My Little Lover</div>
        </div>
        <div style={{ color: t.muted, fontSize: 18 }}>›</div>
      </div>

      {/* Stations */}
      <div>
        <div style={{ fontFamily: t.monoFont, fontSize: 11, color: t.muted, letterSpacing: 2, textAlign: 'center', margin: '4px 0 12px' }}>
          — SELECT STATION —
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {DECADES.map((d, i) => (
            <V1_StationCard key={d.id} decade={d} theme={t} onClick={() => onSelectStation(d.id)} playing={i === 1} />
          ))}
        </div>
      </div>

      {/* Favorites */}
      <div style={{
        background: t.cardBg, borderRadius: 14, padding: '12px 14px',
        border: t.panelBorder, display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <div style={{
          width: 42, height: 42, borderRadius: 21,
          background: 'oklch(0.35 0.08 20)', border: `1px solid ${t.panelBorderColor}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <svg width="18" height="16" viewBox="0 0 18 16"><path d="M9 15s-6-3.5-6-8a3.5 3.5 0 016.1-2.4A3.5 3.5 0 0115 7c0 4.5-6 8-6 8z" fill="oklch(0.62 0.19 20)"/></svg>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted, letterSpacing: 1.5 }}>FAVORITES</div>
          <div style={{ fontFamily: t.uiFont, fontSize: 15, color: t.text, fontWeight: 600 }}>お気に入り</div>
        </div>
        <div style={{ color: t.muted, fontSize: 18 }}>›</div>
      </div>

      <div style={{ flex: 1 }} />
      <V1_KnobRow theme={t} />
    </div>
  );
}

function V1_Dial({ theme }) {
  const t = theme;
  const marks = [76, 80, 84, 88, 92, 96, 100, 104, 108];
  const needlePos = 62; // percent
  return (
    <div style={{ position: 'relative', height: 36 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: t.monoFont, fontSize: 10, color: t.muted, marginBottom: 4 }}>
        {marks.map(m => <span key={m}>{m}</span>)}
      </div>
      <div style={{ position: 'relative', height: 16, background: t.dialBg, borderRadius: 2, border: `1px solid ${t.panelBorderColor}`, overflow: 'hidden' }}>
        {Array.from({ length: 40 }).map((_, i) => (
          <div key={i} style={{
            position: 'absolute', left: `${(i / 40) * 100}%`, top: 2,
            width: 1, height: i % 5 === 0 ? 12 : 6, background: t.muted, opacity: 0.5,
          }} />
        ))}
        <div style={{
          position: 'absolute', left: `${needlePos}%`, top: -2, bottom: -2, width: 2,
          background: t.accent, boxShadow: `0 0 6px ${t.accent}`,
        }} />
      </div>
    </div>
  );
}

function V1_StationCard({ decade, theme, onClick, playing }) {
  const t = theme;
  return (
    <div onClick={onClick} style={{
      background: t.cardBg, borderRadius: 14,
      border: `1.5px solid ${decade.accent}`,
      padding: '10px 12px', display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer',
      boxShadow: `0 0 0 1px ${decade.accent}22, 0 4px 12px rgba(0,0,0,0.2)`,
    }}>
      <V1_CassetteMini accent={decade.accent} theme={t} spinning={playing} />
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: t.uiFont, fontSize: 20, fontWeight: 700, color: t.text, lineHeight: 1 }}>{decade.label}</div>
        <div style={{ fontFamily: t.monoFont, fontSize: 11, color: t.muted, letterSpacing: 2, marginTop: 2 }}>{decade.en}</div>
      </div>
      {playing && (
        <div style={{ display: 'flex', gap: 2, alignItems: 'flex-end', height: 14, marginRight: 4 }}>
          {[0,1,2,3].map(i => (
            <div key={i} style={{
              width: 2, background: decade.accent, borderRadius: 1,
              animation: `vu 0.${6 + i}s ease-in-out infinite alternate`,
              height: `${40 + i*15}%`,
            }}/>
          ))}
        </div>
      )}
    </div>
  );
}

function V1_CassetteMini({ accent, theme, spinning }) {
  const t = theme;
  return (
    <div style={{
      width: 72, height: 44, borderRadius: 4,
      background: t.cassetteBg,
      border: `1px solid ${t.panelBorderColor}`,
      position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'space-around',
      boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.4)',
    }}>
      {/* tape window */}
      <div style={{
        position: 'absolute', top: 4, left: 6, right: 6, height: 20,
        background: 'rgba(0,0,0,0.5)', borderRadius: 2,
        border: `0.5px solid ${accent}66`,
        display: 'flex', alignItems: 'center', justifyContent: 'space-around',
      }}>
        {[0,1].map(i => (
          <div key={i} style={{
            width: 12, height: 12, borderRadius: '50%',
            background: `radial-gradient(circle, ${accent} 20%, ${t.cassetteBg} 22%, ${t.cassetteBg} 40%, ${accent}88 42%, ${accent}88 60%, ${t.cassetteBg} 62%)`,
            border: `0.5px solid ${accent}88`,
            animation: spinning ? 'spin 2s linear infinite' : 'none',
          }}/>
        ))}
      </div>
      {/* label strip */}
      <div style={{
        position: 'absolute', bottom: 4, left: 4, right: 4, height: 12,
        background: `linear-gradient(90deg, ${accent}44, ${accent}22)`,
        borderRadius: 1,
      }} />
    </div>
  );
}

function V1_KnobRow({ theme }) {
  const t = theme;
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-around',
      padding: '14px 12px 6px', borderTop: `1px solid ${t.panelBorderColor}`,
      background: t.chromeBg,
      borderRadius: '0 0 12px 12px',
      marginLeft: -18, marginRight: -18, marginBottom: -24,
      paddingBottom: 18, paddingLeft: 20, paddingRight: 20,
    }}>
      <V1_Knob theme={t} size={26} />
      <V1_Knob theme={t} size={22} />
      <div style={{
        width: 52, height: 30, borderRadius: 4, background: '#000',
        border: `1px solid ${t.panelBorderColor}`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: 'inset 0 0 4px rgba(0,0,0,0.8)',
      }}>
        <svg width="38" height="20" viewBox="0 0 38 20">
          <path d="M2 18 A 17 17 0 0 1 36 18" fill="none" stroke="#333" strokeWidth="1"/>
          <path d="M2 18 A 17 17 0 0 1 15 4" fill="none" stroke="oklch(0.68 0.17 140)" strokeWidth="1.5"/>
          <path d="M15 4 A 17 17 0 0 1 25 4" fill="none" stroke="oklch(0.75 0.18 90)" strokeWidth="1.5"/>
          <path d="M25 4 A 17 17 0 0 1 36 18" fill="none" stroke="oklch(0.65 0.22 30)" strokeWidth="1.5"/>
          <line x1="19" y1="18" x2="23" y2="6" stroke="#fff" strokeWidth="1"/>
        </svg>
      </div>
      <V1_Knob theme={t} size={22} />
      <V1_Knob theme={t} size={26} />
    </div>
  );
}

function V1_Knob({ theme, size = 24 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: 'radial-gradient(circle at 30% 30%, #555, #222 60%, #0a0a0a)',
      border: '1px solid #111',
      boxShadow: 'inset 0 1px 1px rgba(255,255,255,0.1), 0 1px 2px rgba(0,0,0,0.6)',
      position: 'relative',
    }}>
      <div style={{
        position: 'absolute', top: 2, left: '50%', width: 1, height: size*0.3,
        background: '#888', transform: 'translateX(-50%)',
      }} />
    </div>
  );
}

// ── Player ────────────────────────────────────────────────────
function V1_Player({ song, theme, onBack }) {
  const t = theme;
  const [playing, setPlaying] = React.useState(true);
  const [liked, setLiked] = React.useState(false);

  return (
    <div style={{ padding: '16px 0 24px', display: 'flex', flexDirection: 'column', gap: 14, minHeight: '100%', boxSizing: 'border-box' }}>
      {/* Transport bar */}
      <div style={{ padding: '0 14px', display: 'flex', gap: 8, alignItems: 'center' }}>
        <V1_TransportBtn theme={t} onClick={onBack}>
          <svg width="14" height="14" viewBox="0 0 14 14"><path d="M9 2L4 7l5 5" stroke={t.text} strokeWidth="1.8" fill="none" strokeLinecap="round"/></svg>
        </V1_TransportBtn>
        <V1_TransportBtn theme={t}>
          <svg width="14" height="14" viewBox="0 0 14 14"><path d="M9 2L4 7l5 5M4 2v10" stroke={t.muted} strokeWidth="1.5" fill="none" strokeLinecap="round"/></svg>
        </V1_TransportBtn>
        <div style={{ flex: 1 }} />
        <V1_TransportBtn theme={t} onClick={() => setPlaying(!playing)} label="停止">
          <svg width="10" height="10" viewBox="0 0 10 10"><rect x="1" y="1" width="8" height="8" fill={t.text}/></svg>
        </V1_TransportBtn>
        <V1_TransportBtn theme={t} active label="自動">
          <svg width="12" height="12" viewBox="0 0 12 12"><circle cx="6" cy="6" r="4" fill="none" stroke="#fff" strokeWidth="1.5"/><circle cx="6" cy="6" r="1" fill="#fff"/></svg>
        </V1_TransportBtn>
        <V1_TransportBtn theme={t} label="リピート">
          <svg width="14" height="14" viewBox="0 0 14 14"><path d="M3 5h7l-1.5-1.5M11 9H4l1.5 1.5" stroke={t.text} strokeWidth="1.3" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </V1_TransportBtn>
        <div style={{ flex: 1 }} />
        <V1_TransportBtn theme={t} label="次の曲">
          <svg width="14" height="14" viewBox="0 0 14 14"><path d="M5 2l5 5-5 5M10 2v10" stroke={t.text} strokeWidth="1.5" fill="none" strokeLinecap="round"/></svg>
        </V1_TransportBtn>
      </div>

      {/* Cassette window with YouTube */}
      <div style={{
        margin: '0 14px',
        background: t.cassetteBg, borderRadius: 10,
        padding: 10, border: `1px solid ${t.panelBorderColor}`,
        boxShadow: 'inset 0 2px 6px rgba(0,0,0,0.5), 0 2px 8px rgba(0,0,0,0.3)',
      }}>
        <div style={{
          position: 'relative', paddingBottom: '56.25%', background: '#000',
          borderRadius: 6, overflow: 'hidden',
          border: `1px solid ${t.panelBorderColor}`,
        }}>
          <Placeholder theme={t} label={`${song.title}\n${song.artist}`} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8 }}>
          <div style={{
            fontFamily: t.monoFont, fontSize: 10, color: t.muted,
            border: `1px solid ${t.panelBorderColor}`, borderRadius: 12, padding: '2px 8px',
          }}>1×</div>
          <div style={{ flex: 1, height: 14, position: 'relative' }}>
            <V1_Dial theme={t} />
          </div>
        </div>
      </div>

      {/* Song info */}
      <div style={{ margin: '0 14px', padding: '10px 14px',
        background: t.cardBg, borderRadius: 10, border: t.panelBorder,
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <div style={{ color: t.accent, fontSize: 16 }}>♪</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: t.uiFont, fontSize: 16, fontWeight: 700, color: t.text }}>{song.title}</div>
          <div style={{ fontFamily: t.monoFont, fontSize: 11, color: t.muted }}>{song.artist}・{song.year}</div>
        </div>
        <button onClick={() => setLiked(!liked)} style={{
          background: 'transparent', border: `1px solid ${liked ? t.accent : t.panelBorderColor}`,
          borderRadius: 16, padding: '4px 10px', display: 'flex', alignItems: 'center', gap: 4,
          color: liked ? t.accent : t.muted, fontFamily: t.uiFont, fontSize: 12, cursor: 'pointer',
        }}>
          <svg width="12" height="11" viewBox="0 0 12 11"><path d="M6 10s-4-2.3-4-5.3A2.3 2.3 0 016 3a2.3 2.3 0 014 1.7c0 3-4 5.3-4 5.3z" fill={liked ? t.accent : 'none'} stroke={liked ? t.accent : t.muted} strokeWidth="1"/></svg>
          Like
        </button>
      </div>

      {/* Chord progression — sections with tape-strip design */}
      <div style={{ padding: '0 14px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {song.sections.map((sec, si) => (
          <V1_Section key={si} section={sec} theme={t} />
        ))}
      </div>

      <div style={{ flex: 1 }} />
      <V1_KnobRow theme={t} />
    </div>
  );
}

function V1_TransportBtn({ children, label, active, onClick, theme }) {
  const t = theme;
  return (
    <button onClick={onClick} style={{
      background: active ? t.accent : t.cardBg,
      border: `1px solid ${active ? t.accent : t.panelBorderColor}`,
      borderRadius: 8, padding: '6px 10px',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
      color: active ? t.bg : t.text, cursor: 'pointer', minWidth: 38,
      fontFamily: t.uiFont, fontSize: 10, fontWeight: 600,
    }}>
      {children}
      {label && <span>{label}</span>}
    </button>
  );
}

function V1_Section({ section, theme }) {
  const t = theme;
  return (
    <div>
      <div style={{
        fontFamily: t.monoFont, fontSize: 11, color: t.muted,
        letterSpacing: 2, marginBottom: 6, display: 'flex', alignItems: 'center', gap: 8,
      }}>
        <span style={{ width: 6, height: 6, background: t.accent, borderRadius: '50%' }} />
        {section.name.toUpperCase()}
        <span style={{ flex: 1, height: 1, background: t.panelBorderColor }} />
        <span style={{ opacity: 0.7 }}>{section.chords.length} chords</span>
      </div>
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {section.chords.map((c, i) => (
          <ChordChip key={i} name={c} theme={t} />
        ))}
      </div>
    </div>
  );
}

function ChordChip({ name, theme, size = 56 }) {
  const t = theme;
  const color = chordColor(name);
  return (
    <div style={{
      width: size, borderRadius: 8,
      background: t.cardBg, border: `1px solid ${color}66`,
      padding: '4px 4px 5px', boxShadow: `0 0 0 1px ${color}22, inset 0 1px 0 rgba(255,255,255,0.04)`,
    }}>
      <div style={{
        fontFamily: t.uiFont, fontSize: 14, fontWeight: 700, color,
        textAlign: 'center', lineHeight: 1.1,
      }}>{name}</div>
      <ChordDiagram name={name} size={size - 8} stroke={t.text} />
    </div>
  );
}

function Placeholder({ theme, label }) {
  const t = theme;
  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: `repeating-linear-gradient(135deg, ${t.placeholderA} 0 8px, ${t.placeholderB} 8px 16px)`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: t.monoFont, fontSize: 11, color: t.muted,
      whiteSpace: 'pre-line', textAlign: 'center', padding: 12, letterSpacing: 1,
    }}>
      {label}
    </div>
  );
}

Object.assign(window, { V1_Home, V1_Player });
