// Variation C — Frequency Spectrum
// Home: big tuning dial with year-based freq. Player: rich info, horizontal chord diagrams.

function V3_Home({ theme, onSelectStation, onResume }) {
  const t = theme;
  const [selectedIdx, setSelectedIdx] = React.useState(1);
  const selected = DECADES[selectedIdx];
  // Year-based frequencies
  const DECADE_FREQ = ['1980.0', '1990.0', '2000.0'];
  const freq = DECADE_FREQ[selectedIdx];

  return (
    <div style={{ padding: '18px 16px 20px', display: 'flex', flexDirection: 'column', gap: 16, minHeight: '100%', boxSizing: 'border-box' }}>
      {/* Logo */}
      <div style={{ textAlign: 'center' }}>
        <div style={{
          fontFamily: '"Playfair Display", Georgia, serif',
          fontStyle: 'italic', fontWeight: 700, fontSize: 30,
          background: t.logoGradient, WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent', backgroundClip: 'text',
          letterSpacing: 0.5, lineHeight: 1.1,
        }}>Guitar Chord Radio</div>
        <div style={{
          fontFamily: t.uiFont, fontWeight: 500, fontSize: 14, color: t.text,
          letterSpacing: 4, marginTop: 2, opacity: 0.85,
        }}>ギターコードラジオ</div>
        <div style={{ fontFamily: t.monoFont, fontSize: 9, color: t.muted, letterSpacing: 3, marginTop: 4 }}>
          FM ・ STEREO ・ ONLINE
        </div>
      </div>

      {/* Big tuning dial — hero */}
      <div style={{
        background: t.panelBg, borderRadius: 14,
        border: t.panelBorder, padding: '16px 14px 18px',
        boxShadow: t.panelShadow,
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <span style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted, letterSpacing: 2 }}>TUNING ▸ {selected.en}</span>
          <div style={{
            fontFamily: t.monoFont, fontSize: 10, color: selected.accent,
            border: `1px solid ${selected.accent}`, borderRadius: 10, padding: '1px 7px',
            boxShadow: `0 0 8px ${selected.accent}44`,
          }}>● LIVE</div>
        </div>

        {/* Frequency display */}
        <div style={{
          background: '#000', borderRadius: 6, padding: '12px 12px',
          border: `1px solid ${t.panelBorderColor}`,
          boxShadow: 'inset 0 2px 6px rgba(0,0,0,0.8)',
        }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: 6 }}>
            <div style={{
              fontFamily: t.monoFont, fontSize: 38, fontWeight: 700,
              color: selected.accent, letterSpacing: -0.5, lineHeight: 1,
              textShadow: `0 0 12px ${selected.accent}88`,
              fontVariantNumeric: 'tabular-nums',
            }}>{freq}</div>
            <div style={{ fontFamily: t.monoFont, fontSize: 14, color: t.muted }}>kHz</div>
          </div>

          <V3_DialRuler theme={t} selectedIdx={selectedIdx} decades={DECADES} freqs={DECADE_FREQ} />

          <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: 8, gap: 6 }}>
            {DECADES.map((d, i) => (
              <button key={d.id} onClick={() => setSelectedIdx(i)} style={{
                flex: 1, background: selectedIdx === i ? `${d.accent}22` : 'transparent',
                border: `1px solid ${selectedIdx === i ? d.accent : t.panelBorderColor}`,
                borderRadius: 4, padding: '6px 0', cursor: 'pointer',
                color: selectedIdx === i ? d.accent : t.muted,
                fontFamily: t.monoFont, fontSize: 11, fontWeight: 600, letterSpacing: 1,
              }}>
                {d.label}
              </button>
            ))}
          </div>
        </div>

        <button onClick={() => onSelectStation(selected.id)} style={{
          width: '100%', marginTop: 12, background: selected.accent,
          border: 'none', borderRadius: 8, padding: '12px',
          color: '#000', fontFamily: t.uiFont, fontSize: 14, fontWeight: 700,
          cursor: 'pointer', letterSpacing: 1,
          boxShadow: `0 0 16px ${selected.accent}55, inset 0 -2px 0 rgba(0,0,0,0.2)`,
        }}>
          TUNE IN ▸ {selected.label}
        </button>
      </div>

      {/* Last tuned */}
      <div onClick={onResume} style={{
        background: t.cardBg, borderRadius: 10, padding: '10px 12px',
        border: t.panelBorder, display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer',
      }}>
        <V3_MiniEq theme={t} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: t.monoFont, fontSize: 9, color: t.muted, letterSpacing: 2 }}>LAST TUNED</div>
          <div style={{ fontFamily: t.uiFont, fontSize: 13, color: t.text, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            Hello, Again — My Little Lover
          </div>
        </div>
        <svg width="12" height="12" viewBox="0 0 12 12"><path d="M2 2l4 4-4 4M6 2l4 4-4 4" stroke={t.muted} strokeWidth="1.2" fill="none" strokeLinecap="round"/></svg>
      </div>

      {/* Root color legend */}
      <div style={{
        background: t.panelBg, borderRadius: 10, padding: '10px 12px', border: t.panelBorder,
      }}>
        <div style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted, letterSpacing: 2, marginBottom: 8 }}>
          ROOT SPECTRUM
        </div>
        <div style={{ display: 'flex', gap: 2 }}>
          {ROOT_ORDER.map(n => (
            <div key={n} style={{ flex: 1, textAlign: 'center' }}>
              <div style={{ height: 14, background: ROOT_COLORS[n], borderRadius: 2 }}/>
              <div style={{ fontFamily: t.monoFont, fontSize: 9, color: t.muted, marginTop: 3 }}>{n}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ flex: 1 }} />
      <V1_KnobRow theme={t} />
    </div>
  );
}

function V3_DialRuler({ theme, selectedIdx, decades, freqs }) {
  const t = theme;
  const positions = [0.18, 0.5, 0.82];
  return (
    <div style={{ position: 'relative', height: 42, marginTop: 10 }}>
      <div style={{ position: 'absolute', top: 14, left: 0, right: 0, height: 20 }}>
        {Array.from({ length: 60 }).map((_, i) => (
          <div key={i} style={{
            position: 'absolute', left: `${(i / 59) * 100}%`, top: 0,
            width: 1, height: i % 5 === 0 ? 14 : 7,
            background: t.muted, opacity: 0.5,
          }}/>
        ))}
      </div>
      {decades.map((d, i) => (
        <div key={d.id} style={{
          position: 'absolute', left: `${positions[i] * 100}%`, top: 0,
          transform: 'translateX(-50%)',
          fontFamily: theme.monoFont, fontSize: 8, color: d.accent, letterSpacing: 1,
        }}>
          {freqs[i]}
        </div>
      ))}
      <div style={{
        position: 'absolute', left: `${positions[selectedIdx] * 100}%`, top: 10, bottom: 0,
        width: 2, background: decades[selectedIdx].accent,
        boxShadow: `0 0 8px ${decades[selectedIdx].accent}`,
        transform: 'translateX(-50%)', transition: 'left 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
      }}/>
      <div style={{
        position: 'absolute', left: `${positions[selectedIdx] * 100}%`, top: 6,
        width: 10, height: 10, borderRadius: '50%', background: decades[selectedIdx].accent,
        boxShadow: `0 0 10px ${decades[selectedIdx].accent}`,
        transform: 'translate(-50%, 0)', transition: 'left 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
      }}/>
    </div>
  );
}

function V3_MiniEq({ theme }) {
  return (
    <div style={{
      width: 40, height: 28, background: '#000', borderRadius: 4,
      border: `1px solid ${theme.panelBorderColor}`,
      display: 'flex', alignItems: 'flex-end', justifyContent: 'center', gap: 2, padding: 3,
    }}>
      {[0,1,2,3,4,5].map(i => (
        <div key={i} style={{
          width: 3, background: theme.accent,
          height: `${30 + (i * 12) % 60}%`, borderRadius: 1,
          animation: `vu 0.${4+i}s ease-in-out infinite alternate`,
        }}/>
      ))}
    </div>
  );
}

// ── Player V3 — richer ────────────────────────────
function V3_Player({ song, theme, onBack }) {
  const t = theme;
  const [liked, setLiked] = React.useState(false);
  const [playing, setPlaying] = React.useState(true);
  const [speed, setSpeed] = React.useState('1.0x');
  const [autoScroll, setAutoScroll] = React.useState(true);
  const [loop, setLoop] = React.useState(false);

  return (
    <div style={{ padding: '14px 0 20px', display: 'flex', flexDirection: 'column', gap: 12, minHeight: '100%', boxSizing: 'border-box' }}>
      {/* Header transport */}
      <div style={{ padding: '0 14px', display: 'flex', gap: 6, alignItems: 'center' }}>
        <V3_HeaderBtn theme={t} onClick={onBack}>
          <svg width="12" height="12" viewBox="0 0 12 12"><path d="M8 2L3 6l5 4" stroke={t.text} strokeWidth="1.8" fill="none" strokeLinecap="round"/></svg>
          <span>戻る</span>
        </V3_HeaderBtn>
        <V3_HeaderBtn theme={t}>
          <svg width="12" height="12" viewBox="0 0 12 12"><path d="M9 2L4 6l5 4M4 2v8" stroke={t.muted} strokeWidth="1.5" fill="none" strokeLinecap="round"/></svg>
          <span>前の曲</span>
        </V3_HeaderBtn>
        <div style={{ flex: 1 }} />
        <V3_HeaderBtn theme={t} onClick={() => setPlaying(!playing)}>
          {playing ? (
            <svg width="10" height="10" viewBox="0 0 10 10"><rect x="1" y="1" width="3" height="8" fill={t.text}/><rect x="6" y="1" width="3" height="8" fill={t.text}/></svg>
          ) : (
            <svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 1v8l7-4z" fill={t.text}/></svg>
          )}
          <span>{playing ? '停止' : '再生'}</span>
        </V3_HeaderBtn>
        <V3_HeaderBtn theme={t} active={autoScroll} onClick={() => setAutoScroll(!autoScroll)}>
          <svg width="12" height="12" viewBox="0 0 12 12"><circle cx="6" cy="6" r="4" fill="none" stroke={autoScroll ? t.bg : t.text} strokeWidth="1.5"/><circle cx="6" cy="6" r="1" fill={autoScroll ? t.bg : t.text}/></svg>
          <span>自動</span>
        </V3_HeaderBtn>
        <V3_HeaderBtn theme={t} active={loop} onClick={() => setLoop(!loop)}>
          <svg width="14" height="14" viewBox="0 0 14 14"><path d="M3 5h7l-1.5-1.5M11 9H4l1.5 1.5" stroke={loop ? t.bg : t.text} strokeWidth="1.3" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
          <span>リピート</span>
        </V3_HeaderBtn>
        <div style={{ flex: 1 }} />
        <V3_HeaderBtn theme={t}>
          <svg width="12" height="12" viewBox="0 0 12 12"><path d="M3 2l5 4-5 4M8 2v8" stroke={t.text} strokeWidth="1.5" fill="none" strokeLinecap="round"/></svg>
          <span>次の曲</span>
        </V3_HeaderBtn>
      </div>

      {/* Oscilloscope YouTube frame */}
      <div style={{
        margin: '0 14px', background: t.cassetteBg, borderRadius: 10,
        border: `1px solid ${t.panelBorderColor}`, padding: 8,
        boxShadow: 'inset 0 2px 6px rgba(0,0,0,0.5)',
      }}>
        <div style={{
          position: 'relative', paddingBottom: '42%',
          background: '#000', borderRadius: 4, overflow: 'hidden',
          border: `1px solid ${t.panelBorderColor}`,
        }}>
          <Placeholder theme={t} label="YouTube video" />
          <div style={{
            position: 'absolute', inset: 0, pointerEvents: 'none',
            background: `repeating-linear-gradient(0deg, transparent 0 2px, rgba(0,0,0,0.15) 2px 3px)`,
          }}/>
          <div style={{
            position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
            width: 44, height: 44, borderRadius: '50%',
            background: `${t.accent}dd`, display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: `0 0 16px ${t.accent}88`,
          }}>
            <svg width="14" height="14" viewBox="0 0 14 14"><path d="M3 1v12l10-6z" fill="#000"/></svg>
          </div>
          {/* corner freq indicator */}
          <div style={{
            position: 'absolute', top: 6, left: 8,
            fontFamily: t.monoFont, fontSize: 9, color: t.accent, letterSpacing: 1.5,
            textShadow: `0 0 8px ${t.accent}`,
          }}>● 1990.0 kHz</div>
        </div>

        {/* Progress + speed */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8 }}>
          <button onClick={() => setSpeed(speed === '1.0x' ? '0.75x' : speed === '0.75x' ? '1.25x' : '1.0x')} style={{
            background: 'transparent', border: `1px solid ${t.panelBorderColor}`, borderRadius: 12,
            padding: '2px 8px', color: t.muted, fontFamily: t.monoFont, fontSize: 10, cursor: 'pointer',
          }}>{speed}</button>
          <div style={{ flex: 1, height: 4, background: t.panelBorderColor, borderRadius: 2, position: 'relative' }}>
            <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: '38%', background: t.accent, borderRadius: 2 }}/>
            <div style={{ position: 'absolute', left: '38%', top: -4, width: 12, height: 12, borderRadius: '50%', background: t.accent, transform: 'translateX(-50%)', boxShadow: `0 0 0 2px ${t.cassetteBg}, 0 0 8px ${t.accent}66` }}/>
          </div>
          <span style={{ fontFamily: t.monoFont, fontSize: 10, color: t.muted, fontVariantNumeric: 'tabular-nums' }}>2:03 / 5:18</span>
        </div>
      </div>

      {/* Song info + Like */}
      <div style={{
        margin: '0 14px', padding: '10px 12px',
        background: t.cardBg, borderRadius: 10, border: t.panelBorder,
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <div style={{ color: t.accent, fontSize: 18 }}>♪</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: t.uiFont, fontSize: 15, color: t.text, fontWeight: 700, lineHeight: 1.2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{song.title}</div>
          <div style={{ fontFamily: t.monoFont, fontSize: 11, color: t.muted, marginTop: 2 }}>
            {song.artist} ・ {song.year}
            <span style={{
              marginLeft: 8, padding: '1px 6px', border: `1px solid ${t.panelBorderColor}`,
              borderRadius: 8, color: t.muted,
            }}>KEY: C</span>
          </div>
        </div>
        <button onClick={() => setLiked(!liked)} style={{
          background: liked ? `${t.accent}22` : 'transparent',
          border: `1px solid ${liked ? t.accent : t.panelBorderColor}`,
          borderRadius: 16, padding: '5px 10px', display: 'flex', alignItems: 'center', gap: 4,
          color: liked ? t.accent : t.muted, fontFamily: t.uiFont, fontSize: 12, cursor: 'pointer', fontWeight: 600,
        }}>
          <svg width="12" height="11" viewBox="0 0 12 11"><path d="M6 10s-4-2.3-4-5.3A2.3 2.3 0 016 3a2.3 2.3 0 014 1.7c0 3-4 5.3-4 5.3z" fill={liked ? t.accent : 'none'} stroke={liked ? t.accent : t.muted} strokeWidth="1"/></svg>
          {liked ? 'Liked' : 'Like'}
        </button>
      </div>

      {/* Chord sections */}
      <div style={{ padding: '0 14px', display: 'flex', flexDirection: 'column', gap: 14, paddingBottom: 16 }}>
        {song.sections.map((sec, si) => (
          <V3_Section key={si} section={sec} theme={t} isCurrent={si === 1} />
        ))}
      </div>

      <div style={{ flex: 1 }} />
      <V1_KnobRow theme={t} />
    </div>
  );
}

function V3_HeaderBtn({ children, active, onClick, theme }) {
  const t = theme;
  return (
    <button onClick={onClick} style={{
      background: active ? t.accent : t.cardBg,
      border: `1px solid ${active ? t.accent : t.panelBorderColor}`,
      borderRadius: 8, padding: '5px 8px',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
      color: active ? t.bg : t.text, cursor: 'pointer', minWidth: 36,
      fontFamily: t.uiFont, fontSize: 9, fontWeight: 600,
    }}>{children}</button>
  );
}

function V3_Section({ section, theme, isCurrent }) {
  const t = theme;
  return (
    <div style={{
      background: isCurrent ? `${t.accent}08` : 'transparent',
      border: isCurrent ? `1px solid ${t.accent}44` : `1px solid transparent`,
      borderRadius: 10, padding: isCurrent ? '10px' : '0',
      margin: isCurrent ? '-2px' : '0',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8,
        fontFamily: t.monoFont, fontSize: 10, color: t.muted, letterSpacing: 2,
      }}>
        <span style={{
          background: isCurrent ? t.accent : t.cardBg,
          color: isCurrent ? t.bg : t.text,
          padding: '1px 6px', borderRadius: 2, fontWeight: 700,
          border: isCurrent ? 'none' : `1px solid ${t.panelBorderColor}`,
        }}>{section.name}</span>
        <span style={{ flex: 1, height: 1, background: t.panelBorderColor }}/>
        <span>{section.chords.length} STEPS</span>
        {isCurrent && <span style={{ color: t.accent, fontWeight: 700 }}>▸ NOW</span>}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
        {section.chords.map((c, i) => (
          <V3_ChordTile key={i} name={c} theme={t} active={isCurrent && i === 2} />
        ))}
      </div>
    </div>
  );
}

function V3_ChordTile({ name, theme, active }) {
  const t = theme;
  const color = chordColor(name);
  return (
    <div style={{
      background: active
        ? `linear-gradient(135deg, ${color}44, ${color}18)`
        : `linear-gradient(135deg, ${color}1a, ${color}06)`,
      border: `1px solid ${active ? color : `${color}55`}`,
      borderRadius: 8, padding: '6px 8px',
      display: 'flex', alignItems: 'center', gap: 8,
      boxShadow: active ? `0 0 0 1px ${color}55, 0 0 12px ${color}33` : `0 0 0 1px ${color}0a`,
    }}>
      <div style={{
        fontFamily: t.uiFont, fontSize: 15, fontWeight: 700, color,
        lineHeight: 1, textShadow: `0 0 8px ${color}55`, minWidth: 28,
      }}>{name}</div>
      <ChordDiagram name={name} size={44} stroke={t.text} />
    </div>
  );
}

Object.assign(window, { V3_Home, V3_Player });
