// Horizontal guitar chord diagram — nut on the LEFT (as if holding the guitar).
// Strings run horizontally: top = high E (1st string), bottom = low E (6th string)
// — this matches how a player looks down at their own fretboard.

function ChordDiagram({ name, size = 48, stroke = '#fff', dim = false }) {
  const shape = getShape(name); // [E, A, D, G, B, e] low→high
  const color = chordColor(name);
  // horizontal layout: width is "along the neck", height across strings
  const w = size * 1.15;
  const h = size * 0.85;
  const padL = size * 0.22;   // room for open/mute markers on left
  const padR = size * 0.06;
  const padY = size * 0.10;
  const gridW = w - padL - padR;
  const gridH = h - padY * 2;
  const fretGap = gridW / 4;   // 4 frets
  const stringGap = gridH / 5; // 6 strings
  const shapeDisplay = [...shape].reverse(); // top→bottom = high e → low E

  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
      {/* nut (thick vertical bar on left) */}
      <rect x={padL - 2.5} y={padY} width={2.5} height={gridH} fill={stroke} opacity={dim ? 0.4 : 0.9}/>
      {/* frets */}
      {[1,2,3,4].map(i => (
        <line key={i}
          x1={padL + fretGap*i} y1={padY}
          x2={padL + fretGap*i} y2={padY+gridH}
          stroke={stroke} strokeWidth="0.6" opacity={dim ? 0.2 : 0.4}/>
      ))}
      {/* strings (horizontal) */}
      {[0,1,2,3,4,5].map(i => (
        <line key={i}
          x1={padL} y1={padY + stringGap*i}
          x2={padL + gridW} y2={padY + stringGap*i}
          stroke={stroke} strokeWidth="0.6" opacity={dim ? 0.2 : 0.45}/>
      ))}
      {/* open/mute markers to the left of nut */}
      {shapeDisplay.map((f, i) => {
        const cy = padY + stringGap * i;
        const cx = padL - 8;
        if (f === -1) return <text key={i} x={cx} y={cy + size*0.05} fontSize={size*0.16} fill={stroke} textAnchor="middle" opacity={dim ? 0.4 : 0.8}>×</text>;
        if (f === 0) return <circle key={i} cx={cx} cy={cy} r={size*0.055} fill="none" stroke={stroke} strokeWidth="0.9" opacity={dim ? 0.4 : 0.8}/>;
        return null;
      })}
      {/* fret dots */}
      {shapeDisplay.map((f, i) => {
        if (f <= 0) return null;
        const cy = padY + stringGap * i;
        const cx = padL + fretGap * (f - 0.5);
        return <circle key={i} cx={cx} cy={cy} r={size*0.085} fill={color} opacity={dim ? 0.55 : 1}/>;
      })}
    </svg>
  );
}

Object.assign(window, { ChordDiagram });
