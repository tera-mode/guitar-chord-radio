# Handoff: Guitar Chord Radio — Redesign

## Screenshots
- `screenshots/overview.png` — both screens side-by-side
- `screenshots/home.png` — Home (Frequency Spectrum)
- `screenshots/player.png` — Player (Frequency Spectrum)

## Overview
**Guitar Chord Radio (ギターコードラジオ)** is a mobile app that helps guitarists learn songs by playing them on YouTube while displaying the chord progression. Users tune into "stations" organized by decade (80s / 90s / 2000s), pick a song, and see chord diagrams + section-by-section progression in sync with the music.

This handoff covers a redesign in the **Walkman / cassette-tape aesthetic** with three themes (Retro / Modern / Neon) and a **"Frequency Spectrum"** layout pattern chosen by the user for implementation.

## About the Design Files
The files in this bundle are **design references created as a single HTML + React prototype**. They are not production code to copy directly. Your task is to **recreate these designs in the target codebase's environment** (if one exists) using its established patterns (e.g. React Native, Flutter, SwiftUI). If no environment is set up yet, pick a stack appropriate for the app (React Native or Flutter recommended for cross-platform mobile).

The prototype uses inline React with Babel for rapid iteration — do not ship this approach. Use your framework's idiomatic components.

## Fidelity
**High fidelity.** All colors, typography, spacing, border radii, and component states are intentional and should be matched closely. One exception: the YouTube player is shown as a striped placeholder — integrate the real YouTube iframe/player API in the implementation.

## Selected Design Pattern
The user selected **"Frequency Spectrum" (V3)**. Only this pattern needs implementing. V1 (Walkman Classic) and V2 (Tape Timeline) files are included in `components/` for reference but are not the spec.

Selected theme: **Retro** (warm amber). The other two themes (Modern / Neon) are optional nice-to-haves and are fully defined in the prototype's theme object.

---

## Screens

### 1. HOME — Station Selector

**Purpose:** Let the user pick a decade station and tune in. Also surface resume-listening and the root-note color legend.

**Layout (top to bottom, 16px horizontal padding, 16px vertical gaps):**
1. **Logo block** (centered)
   - "Guitar Chord Radio" — Playfair Display Italic 700, 30px, gold gradient text
   - "ギターコードラジオ" — Inter 500, 14px, letter-spacing 4px, 85% opacity
   - "FM ・ STEREO ・ ONLINE" — Space Mono, 9px, letter-spacing 3px, muted
2. **Tuning dial panel** — dark panel, radius 14px
   - Header row: `TUNING ▸ 90'S HITS` left / `● LIVE` badge right (accent-colored border + glow)
   - Black display box, radius 6px, inset shadow:
     - Large frequency readout: **1980.0 / 1990.0 / 2000.0 kHz**, Space Mono 700 38px, accent color with 12px text-shadow glow
     - Tick-ruler with moving needle (60 ticks, tall every 5th)
     - Three decade buttons in a row (80年代 / 90年代 / 2000年代), active = accent tint background + accent border
   - Primary CTA: `TUNE IN ▸ {decade}` — full-width button in the decade's accent color, black text, 16px text-shadow glow
3. **Last tuned card** — mini EQ (animated 6-bar VU) + text "Hello, Again — My Little Lover" + `»` chevron
4. **Root spectrum card** — 12 equal-width color bars labeled C, C#, D … B (root-note color legend)
5. **Knob row** (at bottom) — 4 knobs + VU meter glyph (aesthetic, non-functional)

### 2. PLAYER — Song View

**Purpose:** Play a YouTube video and display the chord progression grouped by section (イントロ / Aメロ / サビ / etc). Highlight the currently playing section.

**Layout (top to bottom, 14px horizontal padding, 12px vertical gaps):**
1. **Transport header** — horizontal row of small buttons (icon + label stacked):
   - 戻る (back) / 前の曲 (prev) — left group
   - 停止 (stop/play toggle) / 自動 (auto-scroll, active by default) / リピート (loop) — center group
   - 次の曲 (next) — right
   - Active buttons: accent bg + dark text. Inactive: card bg + border.
2. **Video frame** — cassette-style bezel (cassetteBg, radius 10px, inset shadow):
   - 42% aspect-ratio black inner frame
   - CRT scanline overlay (`repeating-linear-gradient`)
   - Center play button: 44px circle, accent bg + 16px glow, black play triangle
   - Top-left corner badge: `● 1990.0 kHz` in accent, Space Mono 9px with text-shadow
   - Below video: speed toggle pill (0.75x / 1.0x / 1.25x) + progress bar with draggable handle + `2:03 / 5:18` time
3. **Song info card** — ♪ icon, title (Inter 700 15px), artist・year + `KEY: C` pill, Like button (toggles filled heart + accent border)
4. **Chord sections** — one block per section (イントロ, Aメロ, サビ, etc):
   - Label chip (section name, uppercase, accent bg for "current" section)
   - Step count on the right ("N STEPS")
   - Active section shows `▸ NOW` and gets a tinted background + accent border wrapping the whole block
   - **3-column grid** of chord tiles:
     - Tile bg: subtle gradient from the chord's root color
     - Border: 1px chord color @ 55% alpha (full color if active)
     - Active tile: stronger gradient + box-shadow glow
     - Content: chord name (Inter 700 15px, colored, text-shadow glow) + horizontal chord diagram
5. **Knob row** at bottom (same as home)

---

## Components

### ChordDiagram (horizontal)
**Critical: nut is on the LEFT, strings run horizontally, top = high E (1st), bottom = low E (6th).** This matches the player's natural view when holding a guitar.

- SVG, default 48px "size"
- Width: size × 1.15, Height: size × 0.85
- Left padding for open/mute markers (×, ◯) before the nut
- Nut: 2.5px thick vertical bar, full-opacity stroke
- 4 frets: vertical lines, 0.6 stroke, 40% opacity
- 6 strings: horizontal lines, 0.6 stroke, 45% opacity
- Fret dots: circles filled with the chord's root color at 8.5% of size radius
- Open (○) / muted (×) markers at 8px left of the nut

Chord shape data format: `[E, A, D, G, B, e]` low→high. `0` = open, `-1` = muted, `N` = fret N. See `components/chord-data.jsx`.

### Root-note color system
12 colors mapped from 12 chromatic roots via `oklch(0.62 0.17 {hue})`:
- C → hue 0 (red)
- C# → 30
- D → 60 (orange)
- D# → 90
- E → 120 (yellow-green)
- F → 150
- F# → 180 (teal)
- G → 210
- G# → 240 (blue)
- A → 270
- A# → 300 (purple)
- B → 330 (pink)

Enharmonic aliases: Db=C#, Eb=D#, Gb=F#, Ab=G#, Bb=A#.

The `chordColor(name)` helper extracts the root letter (incl. accidental) and returns the matching color. Quality (m, 7, maj7) does not affect color — only root does.

### Knob / VU meter glyphs (home + player bottom)
Decorative. Don't wire them to anything yet. Knobs: radial gradient dark metal with a top tick mark. VU meter: arc segments in green/yellow/red with a needle.

---

## Interactions & Behavior

### Home
- Tapping a decade chip in the tuning dial: smoothly animate the needle to that position (CSS transition `left 0.3s cubic-bezier(0.4, 0, 0.2, 1)`), update frequency readout, update LIVE badge color, update TUNE IN button color.
- Tapping TUNE IN: navigate to the station's song list (not designed — next step).
- Tapping "last tuned" card: resume that song in the Player.

### Player
- Transport buttons toggle their own state (停止 ↔ 再生, 自動 on/off, リピート on/off).
- Speed pill cycles 1.0x → 0.75x → 1.25x → 1.0x.
- Like button toggles filled/outlined heart.
- Progress bar: draggable thumb; seek the underlying YouTube player.
- **Auto-scroll (自動)**: when enabled, the chord section list should scroll so the currently playing chord stays in view. The "current" chord gets the strong gradient + glow (see design tokens). Use the YouTube Player API `onStateChange` + a timestamp map per chord.
- **Current chord** determination: each chord in a section should have a start-time (seconds). Pick the chord whose start-time is the largest value ≤ current playback time.

### Animations
- Spin (cassette reels if used): `transform: rotate(360deg)` over 4s linear infinite.
- VU bars: height oscillates 15% ↔ 90% with staggered durations 0.4–1.0s `ease-in-out infinite alternate`.
- Cursor blink (terminal text in some themes): 1s step-end infinite alternating opacity.

---

## State Management

Home screen:
- `selectedDecadeIdx: 0 | 1 | 2` — which decade is tuned

Player screen:
- `song: Song` — current song object
- `playing: boolean`
- `speed: '0.75x' | '1.0x' | '1.25x'`
- `autoScroll: boolean` — default true
- `loop: boolean`
- `liked: boolean` — persist per-song
- `currentTimeSec: number` — from YouTube player
- `currentChordIndex: { section, chord }` — derived from `currentTimeSec`

App-level:
- `favorites: Song[]` — persisted (AsyncStorage / localStorage / native equivalent)
- `lastTuned: Song | null` — persisted
- `theme: 'retro' | 'modern' | 'neon'` — persisted, default 'retro'

### Data fetching
- Song list per decade: static JSON initially (see `components/chord-data.jsx` for schema). Later, replace with a real backend or a curated YAML/JSON file shipped with the app.
- YouTube embed: use the official YouTube iframe player + the timing map you define per song.

---

## Data Schema

```ts
type Chord = string; // e.g. "C", "Am", "Fmaj7", "G7"

type Section = {
  name: string;           // "イントロ" | "Aメロ" | "Bメロ" | "サビ"
  chords: Chord[];
  // For timing, extend later:
  // timings?: number[];  // start-time (sec) for each chord
};

type Song = {
  id: string;
  title: string;
  artist: string;
  year: number;
  youtubeId?: string;     // not in prototype; add for implementation
  sections: Section[];
  key?: string;           // e.g. "C"
};

type Decade = {
  id: '80s' | '90s' | '2000s';
  label: string;   // "80年代"
  en: string;      // "80'S HITS"
  accent: string;  // oklch color
  freq: string;    // display freq: "1980.0"
};
```

Sample song data in `components/chord-data.jsx`.

---

## Design Tokens — Retro Theme (primary)

### Colors
| Token | Value |
|---|---|
| `bg` | `#1a1512` |
| `text` | `#f5ede2` |
| `muted` | `oklch(0.62 0.02 60)` |
| `accent` | `oklch(0.70 0.17 45)` (warm amber) |
| `panelBg` | `oklch(0.19 0.015 55)` |
| `panelBorder` | `1px solid oklch(0.27 0.015 55)` |
| `cardBg` | `oklch(0.22 0.012 55)` |
| `cassetteBg` | `oklch(0.15 0.012 55)` |
| `terminalBg` | `#0a1508` |
| `terminalText` | `oklch(0.80 0.20 140)` (green phosphor) |

### Decade accents
| Decade | Accent |
|---|---|
| 80s | `oklch(0.68 0.17 30)` — warm amber-red |
| 90s | `oklch(0.72 0.15 80)` — yellow |
| 2000s | `oklch(0.70 0.13 180)` — teal |

### Logo gradient
`linear-gradient(180deg, #f5d68e, #b8892f 50%, #8b6018)` applied via `background-clip: text`.

### Typography
| Use | Font | Weight | Size | Letter-spacing |
|---|---|---|---|---|
| Logo (EN) | Playfair Display Italic | 700 | 30px | 0.5px |
| Logo (JA) | Inter | 500 | 14px | 4px |
| Labels (mono/tech) | Space Mono | 400/700 | 9–11px | 1–3px |
| Body / UI | Inter | 500/600/700 | 10–17px | — |
| Frequency readout | Space Mono | 700 | 38px | -0.5px |

Japanese fallback stack: `Inter, "Hiragino Sans", "Noto Sans JP", system-ui`.

### Spacing
- Screen padding: 14–18px horizontal, 14–20px vertical
- Section gaps (vertical stack): 12–16px
- Card inner padding: 10–14px
- Border radii: 4 (inner) / 6–8 (tiles) / 10 (cards) / 14 (panels)

### Shadows
- Panel: `inset 0 1px 0 oklch(0.30 0.015 55), 0 2px 8px rgba(0,0,0,0.4)`
- Button (CTA): `0 0 16px {accent}55, inset 0 -2px 0 rgba(0,0,0,0.2)`
- Glowing text (freq, chord names): `text-shadow: 0 0 8–12px {color}55`
- Display inset: `inset 0 2px 6px rgba(0,0,0,0.8)`

---

## Assets
The prototype uses no raster assets. The YouTube video area is a placeholder; implement it with the real YouTube Player API. If the production app needs a logo file (e.g. for app icon, splash), commission or export the gold italic "Guitar Chord Radio" text separately.

---

## Files in this bundle
- `Guitar Chord Radio.html` — main HTML shell: renders the phone frame, theme switcher, variation switcher, and tweaks panel
- `components/chord-data.jsx` — **authoritative**: chord shapes, root-color mapping, decade definitions, sample song data
- `components/chord-diagram.jsx` — horizontal SVG chord-diagram component
- `components/variation-3.jsx` — **the selected design (V3 Frequency Spectrum)**: Home + Player screens
- `components/variation-1.jsx` — (reference only) V1 Walkman Classic, for knob-row and section styling
- `components/variation-2.jsx` — (reference only) V2 Tape Timeline
- `components/ios-frame.jsx` — unused iOS frame scaffold (ignore)

## Implementation priority
1. **Data layer** — port `chord-data.jsx` (chord shapes, root colors, decade list, songs) to your framework.
2. **ChordDiagram** component (horizontal, nut-left).
3. **Home screen** — tuning dial, decade chips, TUNE IN CTA.
4. **Player screen** — transport, video frame, song info, chord sections grid.
5. **YouTube integration** — embed + timing → current chord highlighting.
6. **Auto-scroll** — keep current chord in viewport when 自動 is on.
7. **Favorites + Last-tuned persistence.**
8. (Optional) Modern / Neon themes — all tokens are in `Guitar Chord Radio.html` in the `THEMES` object.
